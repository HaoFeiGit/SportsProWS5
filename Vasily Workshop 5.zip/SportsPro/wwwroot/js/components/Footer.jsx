﻿const Footer = () => {
    
        return (

            <footer class="border-top footer text-muted">
                <div class="container">&copy;  - SportsPro</div>
            </footer>



        );
    
}

export default Footer