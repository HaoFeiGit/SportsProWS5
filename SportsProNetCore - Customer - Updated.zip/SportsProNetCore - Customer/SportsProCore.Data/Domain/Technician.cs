﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SportsProCore.Data.Domain
{
    public partial class Technician
    {
        public Technician()
        {
            Incidents = new HashSet<Incident>();
        }

        public int TechnicianId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }

        public virtual ICollection<Incident> Incidents { get; set; }
    }
}
