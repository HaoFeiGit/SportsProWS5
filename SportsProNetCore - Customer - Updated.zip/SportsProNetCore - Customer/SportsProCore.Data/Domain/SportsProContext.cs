﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace SportsProCore.Data.Domain
{
    public partial class SportsProContext : DbContext
    {
        public SportsProContext()
        {
        }

        public SportsProContext(DbContextOptions<SportsProContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Country> Countries { get; set; }
        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<Incident> Incidents { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<Technician> Technicians { get; set; }
        public virtual DbSet<User> Users { get; set; }

       
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Latin1_General_CI_AS");

            modelBuilder.Entity<Country>(entity =>
            {
                entity.Property(e => e.CountryId).HasColumnName("CountryID");

                entity.Property(e => e.Name).IsRequired();
            });

            modelBuilder.Entity<Customer>(entity =>
            {
                entity.HasIndex(e => e.CountryId, "IX_Customers_CountryID");

                entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

                entity.Property(e => e.Address).IsRequired();

                entity.Property(e => e.City).IsRequired();

                entity.Property(e => e.CountryId)
                    .IsRequired()
                    .HasColumnName("CountryID");

                entity.Property(e => e.FirstName).IsRequired();

                entity.Property(e => e.LastName).IsRequired();

                entity.Property(e => e.PostalCode).IsRequired();

                entity.Property(e => e.State).IsRequired();

                entity.HasOne(d => d.Country)
                    .WithMany(p => p.Customers)
                    .HasForeignKey(d => d.CountryId);
            });

            modelBuilder.Entity<Incident>(entity =>
            {
                entity.HasIndex(e => e.CustomerId, "IX_Incidents_CustomerID");

                entity.HasIndex(e => e.ProductId, "IX_Incidents_ProductID");

                entity.HasIndex(e => e.TechnicianId, "IX_Incidents_TechnicianID");

                entity.Property(e => e.IncidentId).HasColumnName("IncidentID");

                entity.Property(e => e.CustomerId).HasColumnName("CustomerID");

                entity.Property(e => e.Description).IsRequired();

                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.Property(e => e.TechnicianId).HasColumnName("TechnicianID");

                entity.Property(e => e.Title).IsRequired();

                entity.HasOne(d => d.Customer)
                    .WithMany(p => p.Incidents)
                    .HasForeignKey(d => d.CustomerId);

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.Incidents)
                    .HasForeignKey(d => d.ProductId);

                entity.HasOne(d => d.Technician)
                    .WithMany(p => p.Incidents)
                    .HasForeignKey(d => d.TechnicianId);
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.Property(e => e.ProductId).HasColumnName("ProductID");

                entity.Property(e => e.Name).IsRequired();

                entity.Property(e => e.ProductCode).IsRequired();

                entity.Property(e => e.YearlyPrice).HasColumnType("decimal(8, 2)");
            });

            modelBuilder.Entity<Technician>(entity =>
            {
                entity.Property(e => e.TechnicianId).HasColumnName("TechnicianID");

                entity.Property(e => e.Email).IsRequired();

                entity.Property(e => e.Name).IsRequired();

                entity.Property(e => e.Phone).IsRequired();
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("User");

                entity.Property(e => e.FullName).IsRequired();

                entity.Property(e => e.Password).IsRequired();

                entity.Property(e => e.Role).IsRequired();

                entity.Property(e => e.Username).IsRequired();
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
