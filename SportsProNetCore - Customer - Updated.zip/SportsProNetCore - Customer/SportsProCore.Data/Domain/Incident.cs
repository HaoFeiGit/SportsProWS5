﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SportsProCore.Data.Domain
{
    public partial class Incident
    {
        public int IncidentId { get; set; }
        public int CustomerId { get; set; }
        public int ProductId { get; set; }
        public int? TechnicianId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime DateOpened { get; set; }
        public DateTime? DateClosed { get; set; }

        public virtual Customer Customer { get; set; }
        public virtual Product Product { get; set; }
        public virtual Technician Technician { get; set; }
    }
}
