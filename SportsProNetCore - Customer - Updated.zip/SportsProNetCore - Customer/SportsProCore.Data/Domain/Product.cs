﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SportsProCore.Data.Domain
{
    public partial class Product
    {
        public Product()
        {
            Incidents = new HashSet<Incident>();
        }

        public int ProductId { get; set; }
        public string ProductCode { get; set; }
        public string Name { get; set; }
        public decimal YearlyPrice { get; set; }
        public DateTime ReleaseDate { get; set; }

        public virtual ICollection<Incident> Incidents { get; set; }
    }
}
